﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtiv7
{
    public partial class Exerc4 : Form
    {
        public Exerc4()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtProducao.Clear();
            txtSalario.Clear();
            txtSalFinal.Clear();
            txtGratificacao.Clear();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double Salario;
            double SalFinal;
            double Gratificacao;
            int Producao;
            int B = 0;
            int C = 0;
            int D = 0;
            if (!int.TryParse(txtProducao.Text, out Producao) || (Producao < 0))
            {
                MessageBox.Show("Valor  A Incorreto");
                Focus();
            }
            else
            {
                if (!double.TryParse(txtSalario.Text, out Salario) || (Salario <= 0))
                {
                    MessageBox.Show("Valor  A Incorreto");
                    Focus();
                }
                else
                {
                    if (!double.TryParse(txtGratificacao.Text, out Gratificacao) || (Gratificacao < 0))
                    {
                        MessageBox.Show("Valor  A Incorreto");
                        Focus();
                    }
                    else
                    {
                        if (Producao >= 150)
                        {
                            B = 1;
                            C = 1;
                            D = 1;
                        }
                        else
                            if (Producao >= 120)
                        {
                            B = 1;
                            C = 1;
                        }
                        else
                                if (Producao >= 100)
                                {
                                    B = 1;
                                }
                    }
                    SalFinal = Salario + (Salario * (0.05 * B + 0.1 * C + 0.1 * D)) + Gratificacao;
                    if((SalFinal >= 7000 && Producao >= 150) && Gratificacao >0)
                    {
                        txtSalFinal.Text = SalFinal.ToString();
                    }
                    else
                       SalFinal = 7000;
                        txtSalFinal.Text = SalFinal.ToString();
                }
            }


        }

        private void txtSalFinal_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
