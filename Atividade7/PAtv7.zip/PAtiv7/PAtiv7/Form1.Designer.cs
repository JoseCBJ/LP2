﻿namespace PAtiv7
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.menuStrip3 = new System.Windows.Forms.MenuStrip();
            this.frmExerc1 = new System.Windows.Forms.ToolStripMenuItem();
            this.frmExerc2 = new System.Windows.Forms.ToolStripMenuItem();
            this.frmExerc3 = new System.Windows.Forms.ToolStripMenuItem();
            this.frmExerc4 = new System.Windows.Forms.ToolStripMenuItem();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip3.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Location = new System.Drawing.Point(0, 48);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuStrip2
            // 
            this.menuStrip2.Location = new System.Drawing.Point(0, 24);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(800, 24);
            this.menuStrip2.TabIndex = 1;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // menuStrip3
            // 
            this.menuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.frmExerc1,
            this.frmExerc2,
            this.frmExerc3,
            this.frmExerc4,
            this.sairToolStripMenuItem});
            this.menuStrip3.Location = new System.Drawing.Point(0, 0);
            this.menuStrip3.Name = "menuStrip3";
            this.menuStrip3.Size = new System.Drawing.Size(800, 24);
            this.menuStrip3.TabIndex = 2;
            this.menuStrip3.Text = "menuStrip3";
            // 
            // frmExerc1
            // 
            this.frmExerc1.Name = "frmExerc1";
            this.frmExerc1.Size = new System.Drawing.Size(72, 20);
            this.frmExerc1.Text = "Exercicio1";
            this.frmExerc1.Click += new System.EventHandler(this.exercicio1ToolStripMenuItem_Click);
            // 
            // frmExerc2
            // 
            this.frmExerc2.Name = "frmExerc2";
            this.frmExerc2.Size = new System.Drawing.Size(72, 20);
            this.frmExerc2.Text = "Exercicio2";
            this.frmExerc2.Click += new System.EventHandler(this.frmExerc2_Click);
            // 
            // frmExerc3
            // 
            this.frmExerc3.Name = "frmExerc3";
            this.frmExerc3.Size = new System.Drawing.Size(72, 20);
            this.frmExerc3.Text = "Exercicio3";
            this.frmExerc3.Click += new System.EventHandler(this.exercicio3ToolStripMenuItem_Click);
            // 
            // frmExerc4
            // 
            this.frmExerc4.Name = "frmExerc4";
            this.frmExerc4.Size = new System.Drawing.Size(72, 20);
            this.frmExerc4.Text = "Exercicio4";
            this.frmExerc4.Click += new System.EventHandler(this.exercicio4ToolStripMenuItem_Click);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(38, 20);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.menuStrip2);
            this.Controls.Add(this.menuStrip3);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip3.ResumeLayout(false);
            this.menuStrip3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.MenuStrip menuStrip3;
        private System.Windows.Forms.ToolStripMenuItem frmExerc1;
        private System.Windows.Forms.ToolStripMenuItem frmExerc2;
        private System.Windows.Forms.ToolStripMenuItem frmExerc3;
        private System.Windows.Forms.ToolStripMenuItem frmExerc4;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
    }
}

