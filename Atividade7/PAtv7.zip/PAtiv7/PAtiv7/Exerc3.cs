﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtiv7
{
    public partial class Exerc3 : Form
    {
        public Exerc3()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtTexto.Clear();
        }

        private void btnEpalin_Click(object sender, EventArgs e)
        {
            string Texto = txtTexto.Text.ToUpper(); //Comparar string
            char[] TextoR = Texto.ToCharArray();
            Array.Reverse(TextoR);
            string TextoRe = new string(TextoR);

            if (string.Compare(Texto, TextoRe, true) == 0)
                MessageBox.Show("É palindromo");
            else
                MessageBox.Show("Não é palindromo");
            







        }
    }
}
