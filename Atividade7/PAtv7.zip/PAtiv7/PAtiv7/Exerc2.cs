﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtiv7
{
    public partial class Exerc2 : Form
    {
       
        public Exerc2()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtResultado.Clear();
            txtInsNum.Clear();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int N;
            double H = 0;
            
            if (!int.TryParse(txtInsNum.Text,out N) || (N <= 0)) 
            {
                MessageBox.Show("Valor  A Incorreto");
                Focus();
            }
            else
            {
                
                for (int i = 1; i <= N; i++)
                {
                    H = H + (1 / (double)i);
                }
                txtResultado.Text = H.ToString();
            }
        }

        private void txtResultado_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
