﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtiv7
{
    public partial class Exerc1 : Form
    {
        public Exerc1()
        {
            InitializeComponent();
        }

        private void rchtxtTexto_TextChanged(object sender, EventArgs e)
        {
            //max length
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            string Frase = rchtxtTexto.Text;
            int NumR = 0;
            int Cont = 0;

            do
            {
                if (Char.ToUpper(Frase[Cont]) == 'R')
                {
                    NumR++;
                }
                Cont++;
            } while (Cont < Frase.Length);
            MessageBox.Show("O texto tem" + NumR.ToString() + "Letras r");
        }

        private void btnNumBranco_Click(object sender, EventArgs e)
        {
            string Frase = rchtxtTexto.Text;
            int Cont = 0;
            int EspacBrancos = 0;
            while(Frase.Length > Cont)
            {
                if (Char.IsWhiteSpace(Frase, Cont))
                    EspacBrancos++;
                Cont++;
            }
            MessageBox.Show("O numero de espaços em branco é:" + EspacBrancos.ToString());
        }

        private void btnLetrasRep_Click(object sender, EventArgs e)
        {
            string FraseMaiuscual = rchtxtTexto.Text.Replace(" ", "");
            string Frase = FraseMaiuscual.ToUpper();
            int Cont;
            int Par = 0;
            
            for(Cont = 0; Cont < (Frase.Length); Cont++)
            {
                if (Frase[Cont] == Frase[Cont +1])
                {
                    Par++;
                    Cont++;
                }
            }
            MessageBox.Show("O numero de par de letras da frase é: " + Par.ToString());
        }
    }
}
