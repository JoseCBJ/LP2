﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtiv7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void exercicio1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Exerc1>().Count() > 0)
            {
                MessageBox.Show("Form ja exixte");
                Application.OpenForms["Exerc1"].BringToFront();
            }
            else
            {
                Exerc1 obj1 = new Exerc1(); //cria objetos pela classe (azul claro)
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void exercicio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Exerc3>().Count() > 0)
            {
                MessageBox.Show("Form ja exixte");
                Application.OpenForms["Exerc3"].BringToFront();
            }
            else
            {
                Exerc3 obj3 = new Exerc3(); //cria objetos pela classe (azul claro)
                obj3.MdiParent = this;
                obj3.WindowState = FormWindowState.Maximized;
                obj3.Show();
            }
        }

        private void exercicio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Exerc4>().Count() > 0)
            {
                MessageBox.Show("Form ja exixte");
                Application.OpenForms["Exerc4"].BringToFront();
            }
            else
            {
                Exerc4 obj4 = new Exerc4(); //cria objetos pela classe (azul claro)
                obj4.MdiParent = this;
                obj4.WindowState = FormWindowState.Maximized;
                obj4.Show();
            }
        }

        private void frmExerc2_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Exerc2>().Count() > 0)
            {
                MessageBox.Show("Form ja exixte");
                Application.OpenForms["Exerc2"].BringToFront();
            }
            else
            {
                Exerc2 obj2 = new Exerc2(); //cria objetos pela classe (azul claro)
                obj2.MdiParent = this;
                obj2.WindowState = FormWindowState.Maximized;
                obj2.Show();
            }
        }
    }
}
