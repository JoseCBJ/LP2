﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Exercicio4 : Form
    {
        public Exercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            string[] Vetor = new string[10];
            string aux = "";
         
            for (int i = 0; i < Vetor.Length; i++)
            {
                aux = Interaction.InputBox($"Digite o {i + 1}º nome", "Entrda de dados");
                if (aux == "")
                {
                    break;
                }
                Vetor[i] = aux;
                aux = aux.Replace(" ", "");
                int Val = aux.Length;
                lstbxResposta.Items.Add("O nome: " + Vetor[i] + " tem " + Val + " Caracteres ");
            }
        }
    }
}
