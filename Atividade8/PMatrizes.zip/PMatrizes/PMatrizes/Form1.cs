﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1}º numero", "Entrda de dados");
                if (auxiliar == "")
                    break;
                if (!int.TryParse(auxiliar, out vetor[i]))//quando precisa converter
                {
                    MessageBox.Show("Numero invalido");
                    i--;
                }
            }
            Array.Reverse(vetor);

            auxiliar = "";
            foreach (int j in vetor) //foreach não é utilizado para posição (tipo de dada   variavel in(em) vetor)
            {
                auxiliar += j + "\n";
            }
            MessageBox.Show(auxiliar);

        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList(); // lista dinamica e para adcionar só {}
            lista.Add("Ana");
            lista.Add("André");
            lista.Add("Beatriz");
            lista.Add("Camila João");
            lista.Add("Joana");
            lista.Add("Otavio");
            lista.Add("Marcelo");
            lista.Add("Pedro");
            lista.Add("Thais");

            lista.Remove("Otavio");

            string auxiliar = " ";
            foreach (string i in lista) //string resultado = string. Join("\n", lista.ToArray()) concatena string com separador
            {
                auxiliar += i + " ; ";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            double[] media = new double[20];
            double[,] notas = new double[20, 3];
            string auxiliar = "";
            string saida = "";

            for (int aluno = 0; aluno < 20; aluno++)
            {
                for (int nota = 0; nota < 3; nota++)
                {
                    auxiliar = Interaction.InputBox($"Digite o {nota + 1}º nota", "Entrda de dados");
                    if (auxiliar == "")
                        break;
                    if (!double.TryParse(auxiliar, out notas[aluno, nota]))
                    {
                        MessageBox.Show("Numero invalido");
                        nota--;
                    }
                    media[aluno] += notas[aluno, nota];
                }
                media[aluno] = media[aluno] / 3;
                saida += "aluno " + (aluno + 1) + ":" + "média: " + media[aluno].ToString("n2") + "\n";
            }
            MessageBox.Show(saida);


            
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            
                Exercicio4 obj4 =new Exercicio4();
                obj4.Show();
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            Exercicio5 obj5 =new Exercicio5();
            obj5.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
