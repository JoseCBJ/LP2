﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Exercicio5 : Form
    {
        public Exercicio5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string[] Gabarito = new string[10];
            string[,] Respostas = new string[10, 2];
            string Aux;
            string Opcao;
            string Var = "";

            for (int i = 0; i < Gabarito.Length; i++)
            {
                Aux = Interaction.InputBox($"Digite a {i + 1} resposta", "Entrda do gabarito");
                Opcao = Aux.ToLower();
                if ((Opcao == "a" || Opcao == "b") || (Opcao == "c" || Opcao == "d"))
                Gabarito[i] = Opcao;
                else
                {
                    MessageBox.Show("Opcao invalida");
                    i--;
                }
        }

            for (int j = 0; j < 2; j++)
            {
                for  (int i = 0; i < Gabarito.Length; i++) 
                {
                    Aux = Interaction.InputBox($"Digite a {i + 1} resposta", "Entarda das respostas");
                    Opcao = Aux.ToLower();
                    if ((Opcao == "a" || Opcao == "b") || (Opcao == "c" || Opcao == "d"))
                        Respostas[i, j] = Opcao;
                    else
                    {
                        MessageBox.Show("Opcao invalida");
                        i--;
                    }
                    
                    if (string.Compare(Gabarito[i], Respostas[i, j], true) == 0)
                        Var = " acertou ";
                    else
                        Var = " errou ";
                    
                    lstbxRespostas.Items.Add("O aluno: " + (j + 1) + Var + " questão " + (i + 1) + " era " + Gabarito[i] + " escolheu " + Respostas[i, j]);
                }
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
