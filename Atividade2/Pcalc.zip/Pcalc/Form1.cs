﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double Numero1, Numero2, Resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void msktxResultado_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void msktxNumero1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(msktxNumero1.Text, out Numero1))
            {
                MessageBox.Show("Numero 1 Invalido");
                msktxNumero1.Focus();
            }
            
        }

        private void msktxNumero2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(msktxNumero2.Text, out Numero2))
            {
                MessageBox.Show("Numero 2 Invalido");
                msktxNumero2.Focus();
            }
        }

        private void msktxResultado_Validated(object sender, EventArgs e)
        {

        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 - Numero2;
            msktxResultado.Text = Resultado.ToString();
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 * Numero2;
            msktxResultado.Text += Resultado.ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (Numero2 == 0)
            {
                MessageBox.Show("Numero 2 Invalido");
                msktxNumero2.Focus();
            }
            else
            { 
                Resultado = Numero1 / Numero2;
                msktxResultado.Text = Resultado.ToString();
            }

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            msktxNumero1.Clear();
            msktxNumero2.Clear();
            msktxResultado.Clear();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 + Numero2;
            msktxResultado.Text = Resultado.ToString();
        }
    }
}
